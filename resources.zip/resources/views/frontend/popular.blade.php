@extends('frontend.layout.main')

@section('title', 'Popular Posts - ' . \App\Models\Setting::get('site_name', 'NepBlog'))
@section('meta_description', 'Discover the most popular and trending articles from our blog community.')

@section('content')
    <!-- Hero Section -->

    <section class="relative bg-white py-16 border-b border-gray-200">
        <div class="max-w-screen-2xl mx-auto px-6 lg:px-8">
            <div class="">
                <!-- Breadcrumb -->
                <nav class="text-sm mb-3" aria-label="Breadcrumb">
                    <ol class="list-reset flex text-gray-500">
                        <li>
                            <a href="/" class="hover:text-gray-900">Home</a>
                        </li>
                        <li>
                            <span class="mx-2">/</span>
                        </li>
                        <li class="text-gray-900 font-semibold">
                            Popular Posts
                        </li>
                    </ol>
                </nav>

                <!-- Title -->
                <h1 class="text-3xl md:text-4xl font-bold tracking-tight text-[#ff2953] mb-2 leading-[1.1]">
                    Popular Posts
                </h1>

                <p class="text-xl text-gray-600 leading-relaxed">
                    Discover the most read and shared articles from our community. These posts have captured readers'
                    attention and sparked conversations.
                </p>
            </div>
        </div>
    </section>


    <!-- Posts Grid -->
    <section class="py-16 bg-white">
        <div class="max-w-screen-2xl mx-auto px-4 sm:px-6 lg:px-8">
            @if ($posts->count() > 0)
                <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-3">
                    @foreach ($posts as $post)
                        <article class="bg-white rounded-xl shadow-lg overflow-hidden card-hover">
                            @if ($post->featured_image)
                                <div class="h-48 bg-gray-200">
                                    <img src="{{ asset('uploads/' . $post->featured_image) }}" alt="{{ $post->title }}"
                                        class="w-full h-full object-cover">
                                </div>
                            @endif
                            <div class="p-6">
                                <div class="flex items-center mb-3">
                                    <span
                                        class="inline-flex items-center px-3 py-1 rounded-full text-xs font-medium bg-red-100 text-red-800">
                                        <i class="fas fa-fire mr-1"></i>{{ $post->category->name }}
                                    </span>
                                    <span class="ml-auto text-sm text-gray-500">
                                        {{ $post->published_at->diffForHumans() }}
                                    </span>
                                </div>
                                <h3 class="text-xl font-bold text-gray-900 mb-3 line-clamp-2">
                                    <a href="{{ route('post.show', $post->url_slug ?? $post->slug) }}"
                                        class="hover:text-purple-600 transition-colors">
                                        {{ $post->title }}
                                    </a>
                                </h3>
                                <p class="text-gray-600 mb-4 line-clamp-3">{{ $post->excerpt }}</p>
                                <div class="flex items-center justify-between">
                                    <div class="flex items-center space-x-2">
                                        @if ($post->isAdminPost())
                                            <div
                                                class="w-8 h-8 rounded-full bg-purple-100 flex items-center justify-center">
                                                <i class="fas fa-user-shield text-purple-600 text-sm"></i>
                                            </div>
                                        @else
                                            <img src="{{ $post->user->avatar_url ?? asset('images/default-avatar.png') }}"
                                                alt="{{ $post->user->name ?? 'User' }}" class="w-8 h-8 rounded-full">
                                        @endif
                                        <div class="flex items-center space-x-2">
                                            <span class="text-sm text-gray-700">{{ $post->author_name }}</span>
                                            @if ($post->isAdminPost())
                                                <span
                                                    class="inline-flex items-center px-1.5 py-0.5 rounded text-xs font-medium bg-purple-100 text-purple-800">
                                                    <i class="fas fa-user-shield mr-1"></i>
                                                    Admin
                                                </span>
                                            @else
                                                <span
                                                    class="inline-flex items-center px-1.5 py-0.5 rounded text-xs font-medium bg-blue-100 text-blue-800">
                                                    <i class="fas fa-user mr-1"></i>
                                                    User
                                                </span>
                                            @endif
                                        </div>
                                    </div>
                                    <div class="flex items-center space-x-4 text-sm text-gray-500">
                                        <span class="font-semibold text-red-600"><i
                                                class="fas fa-eye mr-1"></i>{{ number_format($post->views_count) }}</span>
                                        <span><i class="fas fa-clock mr-1"></i>{{ $post->reading_time }} min read</span>
                                    </div>
                                </div>
                            </div>
                        </article>
                    @endforeach
                </div>

                <!-- Pagination -->
                @if ($posts->hasPages())
                    <div class="mt-12">
                        {{ $posts->links() }}
                    </div>
                @endif
            @else
                <div class="text-center py-12">
                    <div class="w-24 h-24 bg-gray-200 rounded-full flex items-center justify-center mx-auto mb-6">
                        <i class="fas fa-fire text-gray-400 text-3xl"></i>
                    </div>
                    <h3 class="text-xl font-semibold text-gray-900 mb-2">No Popular Posts Yet</h3>
                    <p class="text-gray-600">Popular posts will appear here once they gain traction.</p>
                </div>
            @endif
        </div>
    </section>

   

    @push('styles')
        <style>
            .line-clamp-2 {
                display: -webkit-box;
                -webkit-line-clamp: 2;
                -webkit-box-orient: vertical;
                overflow: hidden;
            }

            .line-clamp-3 {
                display: -webkit-box;
                -webkit-line-clamp: 3;
                -webkit-box-orient: vertical;
                overflow: hidden;
            }
        </style>
    @endpush
@endsection
